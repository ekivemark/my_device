"""
Django settings for bbp_oa project.

For more information on this file, see
https://docs.djangoproject.com/en/1.7/topics/settings/

For the full list of settings and their values, see
https://docs.djangoproject.com/en/1.7/ref/settings/
"""

# Build paths inside the project like this: os.path.join(BASE_DIR, ...)
import os
import sys
BASE_DIR = os.path.dirname(os.path.dirname(__file__))
APPS_DIR = os.path.join(BASE_DIR, 'bbp/apps')
sys.path.insert(0, APPS_DIR)

# Quick-start development settings - unsuitable for production
# See https://docs.djangoproject.com/en/1.7/howto/deployment/checklist/


# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True

TEMPLATE_DEBUG = True
# Use this to review Settings at run time
DEBUG_SETTINGS = True

APPLICATION_TITLE="MedYear:Device"

if DEBUG_SETTINGS:
    print "Application: %s" % APPLICATION_TITLE
    print ""
    print "BASE_DIR:%s " % BASE_DIR
    print "APPS_DIR:%s " % APPS_DIR


ALLOWED_HOSTS = []

ADMINS = (
     ('Mark Scrimshire', 'mark@ekivemark.com'),
)

MANAGERS = ADMINS

# Application definition

INSTALLED_APPS = (
    # add admin_bootstrapped items before django.contrib.admin
    'django_admin_bootstrapped.bootstrap3',
    'django_admin_bootstrapped',
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'bootstrap3',
    'bootstrap_themes',
    # https://django-oauth2-provider.readthedocs.org/en/latest/getting_started.html
    #'provider',
    #'provider.oauth2',
    # http://django-oauth-toolkit.readthedocs.org/en/latest/tutorial/tutorial_01.html
    'oauth2_provider',
    'corsheaders',
    'rest_framework',
    'device',
    'bbp.member',

)

AUTHENTICATION_BACKENDS = (
    'oauth2_provider.backends.OAuth2Backend',
    # Uncomment following if you want to access the admin
    'django.contrib.auth.backends.ModelBackend',
    #'...',
)

# https://docs.djangoproject.com/en/1.7/topics/auth/customizing/#a-full-example
AUTH_USER_MODEL = 'member.MyUser'

MIDDLEWARE_CLASSES = (
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.auth.middleware.SessionAuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
    'corsheaders.middleware.CorsMiddleware',
    'oauth2_provider.middleware.OAuth2TokenMiddleware',
)

# http://django-oauth-toolkit.readthedocs.org/en/latest/tutorial/tutorial_01.html
# Allow CORS requests from all domains (just for the scope of this tutorial):
CORS_ORIGIN_ALLOW_ALL = True


ROOT_URLCONF = 'bbp.urls'

WSGI_APPLICATION = 'bbp.wsgi.application'

# Database
# https://docs.djangoproject.com/en/1.7/ref/settings/#databases

DBPATH = os.path.join(BASE_DIR, 'db/db.db')
if DEBUG_SETTINGS:
    print "DBPATH:",DBPATH

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3', # Add 'postgresql_psycopg2', 'mysql', 'sqlite3' or 'oracle'.
        'NAME': DBPATH,                  # Or path to database file if using sqlite3.
        'USER': '',                      # Not used with sqlite3.
        'PASSWORD': '',                  # Not used with sqlite3.
        'HOST': '',                      # Set to empty string for localhost. Not used with sqlite3.
        'PORT': '',                      # Set to empty string for default. Not used with sqlite3.
    }
}

# Internationalization
# https://docs.djangoproject.com/en/1.7/topics/i18n/
# Local time zone for this installation. Choices can be found here:
# http://en.wikipedia.org/wiki/List_of_tz_zones_by_name
# although not all choices may be available on all operating systems.
# On Unix systems, a value of None will cause Django to use the same
# timezone as the operating system.
# If running in a Windows environment this must be set to the same as your
# system time zone.
TIME_ZONE = 'America/New_York'
# TIME_ZONE = 'UTC'

# Language code for this installation. All choices can be found here:
# http://www.i18nguy.com/unicode/language-identifiers.html
LANGUAGE_CODE = 'en-us'
# If you set this to False, Django will make some optimizations so as not
# to load the internationalization machinery.
USE_I18N = True

# If you set this to False, Django will not format dates, numbers and
# calendars according to the current locale.
USE_L10N = True

# If you set this to False, Django will not use timezone-aware datetimes.
USE_TZ = True

# Static files (CSS, JavaScript, Images)
# https://docs.djangoproject.com/en/1.7/howto/static-files/
# Absolute path to the directory static files should be collected to.
# Don't put anything in this directory yourself; store your static files
# in apps' "static/" subdirectories and in STATICFILES_DIRS.
# Example: "/home/media/media.lawrence.com/static/"
# STATIC_ROOT = ''
STATIC_ROOT = os.path.join(BASE_DIR, 'static')
STATIC_URL = '/static/'

if DEBUG_SETTINGS:
    print "STATIC_ROOT:%s" % STATIC_ROOT

ADMIN_MEDIA_PREFIX = '/static/admin'

MAIN_STATIC_ROOT = os.path.join(BASE_DIR, 'mainstatic')
if DEBUG_SETTINGS:
    print "MAIN_STATIC_ROOT:%s" % MAIN_STATIC_ROOT

# Additional locations of static files
STATICFILES_DIRS = (
    # Put strings here, like "/home/html/static" or "C:/www/django/static".
    # Always use forward slashes, even on Windows.
    # Don't forget to use absolute paths, not relative paths.
    MAIN_STATIC_ROOT,
    # '/Users/mark/PycharmProjects/virtualenv/rb/rainbowbutton/static',
)

# List of finder classes that know how to find static files in
# various locations.
STATICFILES_FINDERS = (
    'django.contrib.staticfiles.finders.FileSystemFinder',
    'django.contrib.staticfiles.finders.AppDirectoriesFinder',
#    'django.contrib.staticfiles.finders.DefaultStorageFinder',
)

TEMPLATE_DIRS = (
    # Put strings here, like "/home/html/django_templates" or "C:/www/django/templates".
    # Always use forward slashes, even on Windows.
    # Don't forget to use absolute paths, not relative paths.
    os.path.join(BASE_DIR, 'bbp/templates'),
)

TEMPLATE_VISIBLE_SETTINGS = {
    # Put Strings here that you want to be visible in the templates
    # then add settings_context_processor
    'DEBUG',
    'TEMPLATE_DEBUG',
    'APPLICATION_TITLE',

}

TEMPLATE_MODULES = {
    # Put the names of custom modules in this section
    # This will be used by home.index to display a list of modules
    # that can be called
    'privacy',
    'about',
    'contact',
    'terms',
    'faq',
    'admin',
    'member/view',
    'accounts/logout',
    'accounts/login',

}

TEMPLATE_CONTEXT_PROCESSORS = (
    # Use a context processor to enable frequently used settings variables
    # to be used in templates
    'django.contrib.auth.context_processors.auth',
    'bbp.settings_context_processor.settings',
)

# Default settings for bootstrap 3
BOOTSTRAP3 = {

    # The URL to the jQuery JavaScript file
    'jquery_url': '//code.jquery.com/jquery.min.js',

    # The Bootstrap base URL
    'base_url': '//netdna.bootstrapcdn.com/bootstrap/3.2.0/',

    # The complete URL to the Bootstrap CSS file (None means derive it from base_url)
    'css_url': None,

    # The complete URL to the Bootstrap CSS file (None means no theme)
    'theme_url': None,

    # The complete URL to the Bootstrap JavaScript file (None means derive it from base_url)
    'javascript_url': None,

    # Put JavaScript in the HEAD section of the HTML document (only relevant if you use bootstrap3.html)
    'javascript_in_head': False,

    # Include jQuery with Bootstrap JavaScript (affects django-bootstrap3 template tags)
    'include_jquery': False,

    # Label class to use in horizontal forms
    'horizontal_label_class': 'col-md-2',

    # Field class to use in horizontal forms
    'horizontal_field_class': 'col-md-4',

    # Set HTML required attribute on required fields
    'set_required': True,

    # Set placeholder attributes to label if no placeholder is provided
    'set_placeholder': True,

    # Class to indicate required (better to set this in your Django form)
    'required_css_class': '',

    # Class to indicate error (better to set this in your Django form)
    'error_css_class': 'has-error',

    # Class to indicate success, meaning the field has valid input (better to set this in your Django form)
    'success_css_class': 'has-success',

    # Renderers (only set these if you have studied the source and understand the inner workings)
    'formset_renderers':{
        'default': 'bootstrap3.renderers.FormsetRenderer',
    },
    'form_renderers': {
        'default': 'bootstrap3.renderers.FormRenderer',
    },
    'field_renderers': {
        'default': 'bootstrap3.renderers.FieldRenderer',
        'inline': 'bootstrap3.renderers.InlineFieldRenderer',
    },
}

# http://django-oauth-toolkit.readthedocs.org/en/latest/rest-framework/getting_started.html
OAUTH2_PROVIDER = {
    # this is the list of available scopes
    'SCOPES': {'read': 'Read scope', 'write': 'Write scope', 'groups': 'Access to your groups'}
}


REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': (
        'oauth2_provider.ext.rest_framework.OAuth2Authentication',
    ),
        'DEFAULT_PERMISSION_CLASSES': (
        'rest_framework.permissions.IsAuthenticated',
    ),

}


# @login_required defaults to using settings.LOGIN_URL
# if login_url= is not defined
#LOGIN_URL='/member/login'


# A sample logging configuration. The only tangible logging
# performed by this configuration is to send an email to
# the site admins on every HTTP 500 error when DEBUG=False.
# See http://docs.djangoproject.com/en/dev/topics/logging for
# more details on how to customize your logging configuration.
LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'filters': {
        'require_debug_false': {
            '()': 'django.utils.log.RequireDebugFalse'
        }
    },
    'handlers': {
        'mail_admins': {
            'level': 'ERROR',
            'filters': ['require_debug_false'],
            'class': 'django.utils.log.AdminEmailHandler'
        }
    },
    'loggers': {
        'django.request': {
            'handlers': ['mail_admins'],
            'level': 'ERROR',
            'propagate': True,
        },
    }
}

# Validic Device Integration
# Organization ID and Token are set in local_settings.py
V_ORG_ID = 'fake_value'
V_ACCESS_TOKEN = 'fake_token'
VALIDIC_API = "https://api.validic.com/v1/"


# Make this unique, and don't share it with anybody.
# Setting a false value here and will overwrite using value in local_settings.py
# SECURITY WARNING: keep the secret key used in production secret!

SECRET_KEY = 'fake_value'


# Get Local Settings that you want to keep private.
# Make sure Local_settings.py is excluded from Git
try:
    from local_settings import *
except Exception as e:
    pass

if DEBUG_SETTINGS:
    print "SECRET_KEY:%s" % SECRET_KEY
    print "Validic_Org_ID:%s" % V_ORG_ID
    print "================================================================"
# SECURITY WARNING: keep the secret key used in production secret!

