"""
Django local_settings for medyear project.

For more information on this file, see
https://docs.djangoproject.com/en/1.7/topics/settings/

For the full list of settings and their values, see
https://docs.djangoproject.com/en/1.7/ref/settings/

This file should be EXCLUDED from github.
Place any sensitive configuration information in this file and make sure it is called from
settings.py

"""
__author__ = 'mark'

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = 'MY_VIofqbb$!wo&x0+d=v!i%a6429feh-_sy3=&odqv&0@*xda8+7()VI_MY'
# Secret Key Generator:
# http://www.miniwebtool.com/django-secret-key-generator/

# Validic Client Key:
V_ORG_ID = "53b2d744d4391c28f0000004"
V_ACCESS_TOKEN = "e1c95b3a390b442f06efd266d782734ad886f7f7117453ebabf540b5e73d78d7"

# Admin account and password
# admin / S3creT
# email: mscrimshire@gmail.com

