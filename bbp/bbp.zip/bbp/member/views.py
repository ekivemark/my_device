__author__ = 'mark'
from django.shortcuts import render, get_object_or_404, render_to_response
from django.template import Template, Context, RequestContext
from django.conf import settings as CONFIG
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.http.response import HttpResponse
from oauth2_provider.views.generic import ProtectedResourceView

from models import MyUser

@login_required()
def view_member(request):
    print request.user
    u = MyUser(email=request.user)
    print "User email: %s" % u.email

    print "Member GUID: %s" % (u.member_guid)

    context = {'PAGE_TITLE': 'Member Profile',
                'USER': u,
                'GUID': u.member_guid,
                }
    return render_to_response('member/profile.html', RequestContext(request, context))
